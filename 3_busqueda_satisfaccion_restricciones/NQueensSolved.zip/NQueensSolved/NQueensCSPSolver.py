#csp_Solver.py
#Proyecto CSPSolver
#Autor: Castillo Alcántara Rodrigo

from NQueens import *
import ChessDrawing_pygame
#import time


def NQueens_CSPSolver(csp_info): 					#Función envolvente para la función Real_CSP_Solver, determina además el valor de las variables generales para dicha función
	environment = ChessBoard(int(csp_info))		#Creamos el ambiente en el que se desarrollará nuestro agente
	nQueens(environment, 0)						#Resolvemos el problema según el agente
	return environment							#Retornamos el ambiente con la solución


#Se presenta la implementación del mismo algoritmo para cada problema por separado

def nQueens(chessboard, row):										#Función recursiva para encontrar las posiciones de las reinas en el tablero de ajedrez
#"""
	if len(chessboard.queens) == chessboard.order:					#Caso base: si el número de reinas en la lista de reinas del tablero es el mismo que el orden del tablero:
		return True													#RetornamosTrue, que servirá para diferenciar de cuando estamos regresando a cambiar la posición de una reina y cuando queremos salir de la función
	for column in range(0, chessboard.order):						#Por cada columna en el tablero, desde 0 hasta n (orden):
		o_pair = Queen(row, column)									#Creamos el par ordenado que será un objeto de la clase "Queen" con las coordenadas el renglón y columna en que estamos
		if ChessBoard.isAvailable(chessboard, o_pair):				#Si el par ordenado que acabamos de crear está disponible (no ocupado ni amenzado) en el tablero:
			chessboard.queens.append(o_pair)						#Metemos el par ordenado creado en la lista de reinas del tablero
			if nQueens(chessboard, row+1) == False:					#Hacemos la llamada recursiva, mandando al siguiente renglón del cual estamos usando para colocar la siguiente reina. Se hace la coomparación para saber si el intento de poner una reina falló o si se completó el acomodo
				chessboard.queens.pop()								#En caso de que haya fallado el acomodo, sacamos a la última reina que estuvo en la lista de reinas. Continuamos con el ciclo for
			else: return True 										#En caso de que se retorne True (debido a que ya se terminaron de colocar las piezas -línea 3 de la función-) se retorna True para regresar de cada llamada a la función sin afectar a las reinas
	return False 													#En caso de que se haya terminado de iterar todas las columnas y no se haya encontrado alguna casilla válida retornamos False, que significa que se debe eliminar la última reina en la lista y regresar a seguir buscando
#"""