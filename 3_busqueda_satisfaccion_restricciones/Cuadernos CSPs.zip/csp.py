import copy

class csp:
    def __init__(self):
        self.X = {} # k,v pairs where k is the variable identifier and v is the domain of k.
        self.D = self.getDomains() #k,v pair where k is X[i] and v is a set representing X[i]'s domain.
        self.C = [] #list of k,v tuples where k is the set of variables involved in the constraint, and v is the constraint.
                    # Every item in C is unique.
    
    def getArcs(self):
        self.updateDomains()
        return [Ci for Ci in self.C]
    
    def getAssignments(self):
        assigned = {Xi: Xi.Domain() for Xi in self.X if len(Xi.Domain()) == 1}
        return assigned
    
    def AssignValueTo(self, var, val):
        for Xi in self.X:
            if Xi == var:
                Xi.modifyDomain({val}) 
        self.updateDomains()
    
    '''
        Metodo que genera el grafo de restricciones del problema.
    '''
    def generateGraph(self):
        self.updateDomains()
        graph = dict()
        for Xi in self.X:
            # First we get the variable of which to get its neighbors
            #print('Selected Xi: {var}'.format(var = Xi))

            # We get the neighbors of Xi
            neighbors = list()

            # To get its neighbors we have to ask which variables are related to Xi in the constraints in C.
            #print('Constraints which involve Xi={0}:'.format(Xi))
            for constraint in self.C:
                if Xi in constraint:
                    constraint = set(constraint)
                    #print(constraint)
                    # For every constraint which involves Xi, we remove it and add it into a list of neighbors.
                    related_var = constraint - {Xi}
                    #print('The related variable to Xi={0} is {1}'.format(Xi, related_var))
                    # Once we get the related variable, we pop it off the related_var set to pass it as a regular object to a list
                    # To then have it hashed for uniqueness.
                    neighbors.append(related_var.pop())
                    graph[Xi] = neighbors
                
            #print('The neighbors of Xi={0} are: {1}'.format(Xi, neighbors))
        #print(graph)
        return graph
    
    '''
        Returns a copy of the list of neighbors of Xi
    '''
    def NeighborsOf(self, Xi):
        self.updateDomains()
        neighbors = self.generateGraph()[Xi]
        return neighbors
    
    def updateDomains(self):
        self.D = [{Xi: Xi.Domain()} for Xi in self.X]
    
    def defineVariables(self, X):
        self.X = X
        self.updateDomains()
        
    def defineConstraints(self, C):
        self.C = C
        self.updateDomains()
        
    def getVariables(self):
        return self.X
        
    def getDomains(self):
        self.updateDomains()
        return self.D
        
    def getConstraints(self):
        self.updateDomains()
        return self.C
    
    def IsConsistent(self, var):
        neighbors = self.getNeighborsOf(var)
        
        pass
    
    def __repr__(self):
        self.updateDomains()
        return "CSP: \n X ={vars},\n D ={domains},\n C ={constraints}\n".format(
            vars = self.X, 
            domains=self.D, 
            constraints=self.C)

class csp_variable:
    """
    dom debe ser un set, para que ninguna tupla que representa el dominio de la variable se repita.
    var_id es el identificador de la variable. Por defecto es None.
    """
    def __init__(self, var_id = None, dom = set()):
        self.id = var_id
        self.dom = set(dom)
        self.variable = (var_id, dom)
    
    def __repr__(self):
        return "{id}".format(id=self.id)
    
    '''
        Returns a copy of the domain.
    '''
    def Domain(self):
        return copy.deepcopy(self.dom)
    
    def getID(self):
        return self.id
    
    def modifyDomain(self, newDomain):
        self.dom = newDomain