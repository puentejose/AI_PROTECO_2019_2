#main_CSP_Solver.py
#Proyecto CSPSolver
#Autor: Castillo Alcantara Rodrigo

#import csp_Solver_Unsolved
import NQueensCSPSolver
import ChessDrawing_pygame
import sys

argv = sys.argv 	#Le damos el nombre de argv para usarlo con mayor facilidad
def main(): 										#Funcion principal
	if validations() == False: 				#Se hacen las validaciones necesarias y en caso de que alguna de estas no se cumpla se retorna False
		sys.exit() 									#Lo que nos lleva a dar un mensaje de error y salir del programa
	csp_info = argv[1] 								#Asignamos la informacion que tenemos del problema
	print("Informacion introducida con exto. Generando solucion...") 	#Damos un mensaje de que ha sido correcta la informacion introducida y se comienza a generar la solucion
	
	problem_solved = NQueensCSPSolver.NQueens_CSPSolver(csp_info)

	ChessDrawing_pygame.ChessDrawer(problem_solved) 			#Mandamos a llamar a la funcion que representa graficamente a la solucion, le damos a esta el problema resuelto


def validations(): 											#Funcion de validaciones
	if len(argv) < 2: 						#Primero validamos que se tengan todos los parametros necesarios
		print("Faltan argumentos. Ingrese: python3 CSPSolver.py \"Numero de reinas\" ") #Si no se cumple damos un mensaje
		return False 										#Retornamos False

	chessboard_order = int(argv[1]) 					#Asignamos el orden del tablero como el parametro 2 desde consola
	
	if chessboard_order <= 0 or chessboard_order > 25 or chessboard_order == 2 or chessboard_order == 3: 	#Si el parametro es menor a 0 o es mayor a 19 o es 2 o 3 (para los cuales no hay solucion):
		print("Cantidad de reinas no permitida. Ingrese un numero dentro de [1, 25] excepto 2 y 3. No existe solucion para los dos ultimos") #Damos un mensaje de error
		return False 									#Retornamos False
	
	return True 										#Si ninguna de las codiciones anteriores se cumple entonces retornamos True que implicara que todas las validaciones se satisfacieron adecuadamente

main() 			#Mandamos a llamar a la funcion principal