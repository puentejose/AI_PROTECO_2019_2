#NQueens.py
#Proyecto CSPSolver
#Autor: Castillo Alcántara Rodrigo

class Queen:						#Clase "Reina", se constituye por un par ordenado que es su posición en el tablero.




class ChessBoard:								#Clase "Tablero de ajedrez", tiene una lista de las posiciones disponibles del tablero
