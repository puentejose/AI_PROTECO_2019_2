#csp_Solver.py
#Proyecto CSPSolver
#Autor: Castillo Alcántara Rodrigo

from NQueens import *
import ChessDrawing_pygame
#import time


def NQueens_CSPSolver(csp_info): 					#Función envolvente para la función Real_CSP_Solver, determina además el valor de las variables generales para dicha función



#Se presenta la implementación del mismo algoritmo para cada problema por separado

def nQueens(chessboard, row):										#Función recursiva para encontrar las posiciones de las reinas en el tablero de ajedrez
